module.exports= (client) => {
    console.log(`✅ Sucesfully logged in as ${client.user.tag}!`)
}