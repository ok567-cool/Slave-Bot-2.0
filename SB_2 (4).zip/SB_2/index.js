const { Client, IntentsBitField } = require('discord.js');
const { CommandHandler }          = require('djs-commander');
const { EmbedBuilder }            = require('discord.js');

const mongoose = require('mongoose');
const path     = require('path');

const client = new Client({
    intents:[
        IntentsBitField.Flags.Guilds,
        IntentsBitField.Flags.GuildMembers,
        IntentsBitField.Flags.GuildMessages,
        IntentsBitField.Flags.MessageContent,
    ],
});

new CommandHandler({
    client,
    commandsPath: path.join(__dirname, 'commands'),
    eventsPath: path.join(__dirname, 'events'),
});

(async () =>{
    await mongoose.connect('mongodb+srv://axis:123@cluster0.a9fhait.mongodb.net/?retryWrites=true&w=majority');
    console.log(`✅ Sucessfully connected to the database`)
    client.login('MTE0NzE5OTk1Mjc3NTI5OTE1Mw.Gt7_FT.LAa4q0fA3KewPkCjyhQhKcQLUWMAusFIRUoKLQ');
})();